// 场景式灾区重建与公共卫生仿真逻辑
let map, markersLayer;
const neighborhoods = [];
const results = [];
let simInterval = null;
let simTime = 0;
const MAX_TIME = 30;
let currentScene = 'medical';
const sceneText = {
  medical: '正在展示医疗救护场景，重点观测灾区医疗点与应急资源分配。',
  supply: '正在展示物资补给场景，观察消杀防疫与物资运输行动。',
  education: '正在展示社区教育场景，评估防疫宣传与健康教育效果。'
};

function initMap(){
  map = L.map('map').setView([31.23,121.47], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
  markersLayer = L.layerGroup().addTo(map);
  for(let i=0;i<12;i++){
    const lat = 31.05 + Math.random()*0.36;
    const lng = 121.25 + Math.random()*0.5;
    const pop = Math.round(200 + Math.random()*1500);
    const damage = +(0.3 + Math.random()*0.7).toFixed(2);
    const vulnerable = Math.random()<0.2;
    const medical = Math.random()<0.4;
    const supply = Math.random()<0.4;
    neighborhoods.push({id:i,lat,lng,pop,damage,vulnerable,reconstructed:0,medical,supply});
  }
  drawNeighborhoods();
}

function drawNeighborhoods(){
  markersLayer.clearLayers();
  neighborhoods.forEach(n=>{
    const score = currentScene==='medical' ? (n.medical?0.8:0.4) : currentScene==='supply' ? (n.supply?0.8:0.3) : 0.5;
    const color = getColorByDamage(n.damage*(1-n.reconstructed),score);
    const circle = L.circle([n.lat,n.lng],{radius:220,fillColor:color,color:'#1e293b',weight:1,fillOpacity:0.72})
      .bindPopup(`<strong>小区 ${n.id}</strong><br>人口: ${n.pop}<br>受损: ${(n.damage*100).toFixed(0)}%<br>已重建: ${(n.reconstructed*100).toFixed(0)}%<br>医护协助: ${n.medical? '高':'中'}<br>补给效率: ${n.supply? '高':'中'}`);
    markersLayer.addLayer(circle);
  });
}

function getColorByDamage(d,score){
  const risk = d * (1 - score * 0.3);
  if(risk>0.75) return '#b30000';
  if(risk>0.5) return '#f97316';
  if(risk>0.25) return '#facc15';
  return '#16a34a';
}

function stepSimulation(){
  const resource = +document.getElementById('resource').value;
  const strategy = document.getElementById('strategy').value;
  const list = neighborhoods.slice().sort((a,b)=>{
    if(strategy==='byPopulation') return b.pop - a.pop;
    if(strategy==='byDamage') return (b.damage*(1-b.reconstructed)) - (a.damage*(1-a.reconstructed));
    if(strategy==='byVulnerable') return (b.vulnerable?1:0) - (a.vulnerable?1:0);
    return 0;
  });
  let remaining = resource;
  for(const n of list){
    if(remaining<=0) break;
    const assign = Math.min(1, remaining/4);
    const delta = 0.025 * assign * (currentScene==='medical' && n.medical ? 1.4 : currentScene==='supply' && n.supply ? 1.3 : 1);
    n.reconstructed = Math.min(1, n.reconstructed + delta);
    remaining -= assign;
  }
  neighborhoods.forEach(n=>{
    if(n.reconstructed<0.5){
      n.damage = Math.min(1, n.damage + 0.002);
    }
  });
  simTime++;
  recordMetrics();
  drawNeighborhoods();
  updateUI();
}

function recordMetrics(){
  const totalPop = neighborhoods.reduce((s,n)=>s+n.pop,0);
  const reconstructedPop = neighborhoods.reduce((s,n)=>s + n.pop * n.reconstructed,0);
  const reconstructPct = +(reconstructedPop/totalPop*100).toFixed(2);
  const riskIndex = +(neighborhoods.reduce((s,n)=>s + n.damage*(1-n.reconstructed),0)/neighborhoods.length).toFixed(3);
  results.push({time:simTime,reconstructPct,riskIndex});
}

function updateUI(){
  document.getElementById('timeLabel').textContent = simTime;
  document.getElementById('metricReconstruct').textContent = results.length? results[results.length-1].reconstructPct + '%':'0%';
  document.getElementById('metricRisk').textContent = results.length? results[results.length-1].riskIndex:'0';
  document.getElementById('timeSlider').value = simTime;
  if(window.myChart){
    const labels = results.map(r=>r.time);
    const ds1 = results.map(r=>r.reconstructPct);
    const ds2 = results.map(r=>r.riskIndex);
    window.myChart.data.labels = labels;
    window.myChart.data.datasets[0].data = ds1;
    window.myChart.data.datasets[1].data = ds2;
    window.myChart.update();
  }
}

function initChart(){
  const ctx = document.getElementById('chart').getContext('2d');
  window.myChart = new Chart(ctx,{type:'line',data:{labels:[],datasets:[{label:'重建覆盖率(%)',borderColor:'#0f4c81',backgroundColor:'rgba(15,76,129,0.12)',data:[]},{label:'风险指数',borderColor:'#dc2626',backgroundColor:'rgba(220,38,38,0.12)',data:[]} ]},options:{interaction:{mode:'index'},scales:{y:{beginAtZero:true}}}});
}

function resetSimulation(){
  neighborhoods.length = 0;
  results.length = 0;
  simTime = 0;
  initMap();
  if(window.myChart){window.myChart.data.labels=[];window.myChart.data.datasets.forEach(ds=>ds.data=[]);window.myChart.update();}
  document.getElementById('sceneIntro').textContent = sceneText[currentScene];
}

function startAuto(){
  if(simInterval) return;
  simInterval = setInterval(()=>{
    if(simTime>=MAX_TIME){ pauseAuto(); return; }
    stepSimulation();
  },700);
}

function pauseAuto(){
  if(simInterval){ clearInterval(simInterval); simInterval=null; }
}

function downloadJSON(){
  const payload = {scene:currentScene,params:{resource:+document.getElementById('resource').value,strategy:document.getElementById('strategy').value},neighborhoods,results};
  const blob = new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='scenario.json'; a.click(); URL.revokeObjectURL(url);
}

function exportCSV(){
  let csv = 'time,reconstructPct,riskIndex\n';
  results.forEach(r=>{csv += `${r.time},${r.reconstructPct},${r.riskIndex}\n`});
  const blob = new Blob([csv],{type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='report.csv'; a.click(); URL.revokeObjectURL(url);
}

function setScene(scene){
  currentScene = scene;
  document.querySelectorAll('.scene-btn').forEach(btn=>btn.classList.toggle('active',btn.dataset.scenario===scene));
  document.getElementById('sceneIntro').textContent = sceneText[scene];
  resetSimulation();
}

function attachSceneButtons(){
  document.querySelectorAll('.scene-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      setScene(btn.dataset.scenario);
    });
  });
}

// UI wiring
document.addEventListener('DOMContentLoaded',()=>{
  initMap();
  initChart();
  attachSceneButtons();
  document.getElementById('resource').addEventListener('input',e=>{document.getElementById('resVal').textContent = e.target.value});
  document.getElementById('btnStart').addEventListener('click',startAuto);
  document.getElementById('btnPause').addEventListener('click',pauseAuto);
  document.getElementById('btnReset').addEventListener('click',()=>{pauseAuto();resetSimulation();});
  document.getElementById('btnSave').addEventListener('click',downloadJSON);
  document.getElementById('btnExportCSV').addEventListener('click',exportCSV);
  document.getElementById('timeSlider').addEventListener('input',e=>{simTime=+e.target.value;document.getElementById('timeLabel').textContent=simTime});
  document.getElementById('preset1').addEventListener('click',()=>{document.getElementById('resource').value=8;document.getElementById('resVal').textContent=8;});
  document.getElementById('preset2').addEventListener('click',()=>{document.getElementById('resource').value=3;document.getElementById('resVal').textContent=3;});
  document.getElementById('sceneIntro').textContent = sceneText[currentScene];
});
